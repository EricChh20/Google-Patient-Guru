{\rtf1\ansi\ansicpg1252\cocoartf1671
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # GOOGLE PATIENT GURU\
\
AUTHORS : Tej Patel, Eric Chheang, Akash Pansuriya, Dipak Darbar\
\
Built with : Google Cloud, Google Action, Google Home Mini, DialogFlow, api.ai, Machine Learning, Python, JavaScript.\
\
The Google Patient Guru is responsible for turning Google-Home into a "patient", using the Google APIs, Google Action, and accompanying platforms. It takes help of concepts such as Finite State Machines, Regular Finite Automata and Machine Learning to execute its functions.\
\
The doctor (user) gets to practice the diagnostics skills such as:\
\
- Greeting the patient and having proper bed-side etiquettes.\
- Posting questions to reach the root cause.\
- Ask probing questions, to the patient, to get the symptoms from them.\
- Proposing a probable disease based on the symptoms.\
- Giving a good "Doctor's Report". \
\
The roadblocks we ran into: \
\
- Our initial plan depended on the usage of Amazon Echo Dot instead instead of Google Home Mini. The use of Amazon Web Services was difficult. Added to it the fact that it didn't end there; we had to use Amazon lex to get the state machines and bots up, made it much more difficult as it wasn't that user friendly. Hence, it led to a change in the platform used, and we switched to using Google Home mini instead. \
- One more thing that made the project's execution more difficult, was that two of our teammates were not computer science major and were not able to provide much help in terms of software related tasks, but contributed in many other ways. \
- After all that, in the very end we ran into was hardware related problem. We decided to implement a VR "patient" alongside our Google medical assistant. However, after completing our implementation of a 3D VR mobile character on Unity, the Oculus Rift was unable to sync with our devices as we did not have a device with an HDMI link directly to the GPU. This resulted in am unfinished VR application which we weren't able to test and improve. }